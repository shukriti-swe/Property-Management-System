<?php

return [

    // rented report
    
    'e_s_report' => 'Employee Salary Report',

    's_employee' => 'Select Employee',
    's_month' => 'Select Month',
    's_year' => 'Select Year',
    'submit' => 'Submit',
    'issue_date' => 'Issue Date',
    'name' => 'Name',
    'designation' => 'Designation',
    'salary_month' => 'Salary Month',
    'salary_year' => 'Salary Year',
    'salary' => 'Salary',
];