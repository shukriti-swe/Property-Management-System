<?php
// This is for Visitors Report section

return [

    // common text
    'golden_tower' => 'Golden Tower',
    'cancel' => 'Cancel',
    'created' => 'Created',

    // Visitors Head Info
    'comhead_name' => 'Complains Report',
    'comhead_report' => 'Complain Report Form',
    'comhead_details' => 'K-Block,Mirpur-10,Dhaka-1216 <br>opu@gmail.com <br>1212121212',
    
    // Visitors Info And Print Page
    'com_date' => 'Date',
    'com_month' => 'Month',
    'com_year' => 'Year',
    'com_title' => 'Title',
    'com_des' => 'Description',


    // Visitors report page
    'comre_list' => 'Select Date :',
    'comre_month' => 'Select Month :',
    'comre_year' => 'Select Year :',

    'comre_submit' => 'Submit',
];
