<?php

return [

    // rented report
    
    'r_c_r' => 'Rental Collection Report',
    'r_c_r_f' => 'Rental Collection Report Form',
    'floor_no' => 'Floor No',
    's_unit' => 'Select Unit',
    's_month' => 'Select Month',
    's_year' => 'Select Year',
    'p_status' => 'Payment Status',
    'submit' => 'Submit',

    'date' => 'Date',
    'name' => 'Name',
    'type' => 'Type',
    'floor' => 'Floor',
    'unit' => 'Unit',
    'month' => 'Month',
    'year' => 'Year',
    'rent' => 'Rent',
    'g_b' => 'Gas Bill',
    'e_b' => 'Electric Bill',
    'w_b' => 'Water Bill',
    's_b' => 'Security Bill',
    'u_b' => 'Utility Bill',
    'o_b' => 'Other Bill',
    'total' => 'Total',
    'bill' => 'Bill',
];