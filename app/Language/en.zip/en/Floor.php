<?php
// This is for Floor section

return [

    // common text
    'golden_tower' => 'Golden Tower',
    'cancel' => 'Cancel',
    'created' => 'Created',

    // Floor Add
    'floor_list' => 'Floor List',
    'floor_add' => 'Add New Floor',
    'floor_no' => '* Floor No :',

    // Floor Edit
    'floor_name' => 'Update Floor',

    //Floor List
    'floo_add' => 'Add Floor',
    'floo_no' => 'Floor No',
    'floo_action' => 'Action',
    'floo_edit' => 'Edit',
    'floo_delete' => 'Delete',

];
